import { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, updateTaskSchema, insertBackupSchema } from "@shared/schema";
import { z } from "zod";
import cron from "node-cron";

export async function registerRoutes(app)
  // Task Routes
  
  // Get all tasks with optional filters
  app.get("/api/tasks", async (req, res) => {
    try {
      const filters = {
        status: req.query.status: req.query.subject: req.query.priority: req.query.search: req.query.dueDateFrom ? new Date(req.query.dueDateFrom) 
        dueDateTo: req.query.dueDateTo ? new Date(req.query.dueDateTo) ;
      
      // Remove undefined values
      Object.keys(filters).forEach(key => 
        filters[key=== undefined && delete filters[key);
      
      const tasks = await storage.getTasks(filters);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  // Get task counts for dashboard
  app.get("/api/tasks/counts", async (req, res) => {
    try {
      const counts = await storage.getTaskCounts();
      res.json(counts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch task counts" });
    }
  });

  // Get single task
  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  // Create new task
  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors);
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  // Update task
  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const taskData = updateTaskSchema.parse({ ...req.body, id);
      const task = await storage.updateTask(taskData);
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors);
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  // Delete task
  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const success = await storage.deleteTask(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json({ message: "Task deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Backup Routes

  // Get all backups
  app.get("/api/backups", async (req, res) => {
    try {
      const backups = await storage.getBackups();
      res.json(backups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch backups" });
    }
  });

  // Create manual backup
  app.post("/api/backups", async (req, res) => {
    try {
      // Get all current tasks
      const tasks = await storage.getTasks();
      const counts = await storage.getTaskCounts();
      
      const backupData = {
        tasks,
        counts,
        timestamp: new Date().toISOString(),
      };

      const backup = await storage.createBackup({
        data
        type: "manual",
      });

      // Clean up old backups (keep last 10)
      await storage.deleteOldBackups(10);

      res.status(201).json(backup);
    } catch (error) {
      res.status(500).json({ message: "Failed to create backup" });
    }
  });

  // Restore from backup
  app.post("/api/backups/:id/restore", async (req, res) => {
    try {
      const backups = await storage.getBackups();
      const backup = backups.find(b => b.id === req.params.id);
      
      if (!backup) {
        return res.status(404).json({ message: "Backup not found" });
      }

      const { replaceAll = true } = req.body;

      if (replaceAll) {
        // Delete all current tasks (if requested)
        const currentTasks = await storage.getTasks();
        for (const task of currentTasks) {
          await storage.deleteTask(task.id);
        }
      }

      // Restore tasks from backup
      const backupData = backup.data;
      if (backupData.tasks) {
        for (const task of backupData.tasks) {
          const { id, createdAt, updatedAt, ...taskData } = task;
          await storage.createTask(taskData);
        }
      }

      res.json({ message: "Backup restored successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to restore backup" });
    }
  });

  // Automated daily backup using node-cron
  cron.schedule('0 0 * * *', async () => {
    try {
      console.log('Running automated daily backup...');
      
      const tasks = await storage.getTasks();
      const counts = await storage.getTaskCounts();
      
      const backupData = {
        tasks,
        counts,
        timestamp: new Date().toISOString(),
      };

      await storage.createBackup({
        data
        type: "auto",
      });

      // Clean up old backups (keep last 10)
      await storage.deleteOldBackups(10);
      
      console.log('Automated backup completed successfully');
    } catch (error) {
      console.error('Failed to create automated backup:', error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}