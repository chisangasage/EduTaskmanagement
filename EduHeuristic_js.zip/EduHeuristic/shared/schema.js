import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  subject: text("subject").notNull(),
  priority: text("priority").notNull(), // low, medium, high
  status: text("status").notNull().default("todo"), // todo, in_progress, completed, overdue
  progress: integer("progress").notNull().default(0), // 0-100
  dueDate: timestamp("due_date").notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const backups = pgTable("backups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  data: jsonb("data").notNull(),
  type: text("type").notNull(), // auto, manual
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username
  password);

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id
  createdAt
  updatedAt
  completedAt).extend({
  dueDate: z.string().transform((val) => new Date(val)),
});

export const updateTaskSchema = insertTaskSchema.partial().extend({
  id: z.string(),
  dueDate: z.string().transform((val) => new Date(val)).optional(),
});

export const insertBackupSchema = createInsertSchema(backups).omit({
  id
  createdAt);
