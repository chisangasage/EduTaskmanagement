import { useState } from "react";
import { format, isToday, isPast, parseISO } from "date-fns";
import { Edit, Trash2, Clock, CheckCircle, Play, TriangleAlert, CalendarPlus, Undo } from "lucide-react";
import { useUpdateTask } from "@/hooks/use-tasks";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Task } from "@shared/schema";


export default function TaskCard({ task, onEdit, onDelete, onRefetch }) {
  const [isAnimating, setIsAnimating] = useState(false);
  const updateTaskMutation = useUpdateTask();

  const dueDate = parseISO(task.dueDate.toString());
  const isOverdue = isPast(dueDate) && task.status !== "completed";
  const isDueToday = isToday(dueDate);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-700";
      case "medium":
        return "bg-yellow-100 text-yellow-700";
      case "low":
        return "bg-gray-100 text-gray-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getSubjectColor = (subject) => {
    const colors = {
      mathematics: "bg-blue-100 text-blue-700",
      science: "bg-green-100 text-green-700",
      history: "bg-purple-100 text-purple-700",
      english: "bg-orange-100 text-orange-700",
      other: "bg-gray-100 text-gray-700",
    };
    return colors[subject|| colors.other;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-700";
      case "in_progress":
        return "bg-yellow-100 text-yellow-700";
      case "overdue":
        return "bg-red-100 text-red-700";
      case "todo":
        return "bg-gray-100 text-gray-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case "todo":
        return "To Do";
      case "in_progress":
        return "In Progress";
      case "completed":
        return "Completed";
      case "overdue":
        return "Overdue";
      default;
    }
  };

  const getDueDateText = () => {
    if (task.status === "completed") {
      return task.completedAt ? `Completed ${format(parseISO(task.completedAt.toString()), "MMMM d")}` : "Completed";
    }
    
    if (isOverdue) {
      const daysPast = Math.ceil((new Date().getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
      return `Overdue by ${daysPast} day${daysPast > 1 ? 's' : ''}`;
    }
    
    if (isDueToday) {
      return "Due Today";
    }
    
    return `Due ${format(dueDate, "MMMM d")}`;
  };

  const getDueDateIcon = () => {
    if (task.status === "completed") return CheckCircle;
    if (isOverdue) return TriangleAlert;
    return Clock;
  };

  const getDueDateColor = () => {
    if (task.status === "completed") return "text-green-600";
    if (isOverdue) return "text-destructive";
    if (isDueToday) return "text-destructive";
    return "text-muted-foreground";
  };

  const handleMarkComplete = async () => {
    setIsAnimating(true);
    try {
      await updateTaskMutation.mutateAsync({
        id
        status: "completed",
        progress);
      onRefetch();
    } catch (error) {
      console.error("Failed to mark task complete:", error);
    }
    setTimeout(() => setIsAnimating(false), 600);
  };

  const handleStartTask = async () => {
    try {
      await updateTaskMutation.mutateAsync({
        id
        status: "in_progress",
        progress: Math.max(task.progress, 10),
      });
      onRefetch();
    } catch (error) {
      console.error("Failed to start task:", error);
    }
  };

  const handleUndoComplete = async () => {
    try {
      await updateTaskMutation.mutateAsync({
        id
        status: "in_progress",
        progress);
      onRefetch();
    } catch (error) {
      console.error("Failed to undo completion:", error);
    }
  };

  const handleExtendDeadline = () => {
    onEdit(task);
  };

  const DueDateIcon = getDueDateIcon();

  return (
    <div 
      className={`bg-card border rounded-lg p-4 hover:shadow-lg transition-shadow cursor-pointer group ${
        isOverdue ? "border-destructive" : "border-border"
      } ${task.status === "completed" ? "opacity-75" : ""} ${isAnimating ? "animate-complete-pulse" : ""}`}
      data-testid={`task-card-${task.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Badge className={`text-xs font-medium ${getPriorityColor(task.priority)}`} data-testid={`priority-${task.priority}`}>
            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
          </Badge>
          <Badge className={`text-xs ${getSubjectColor(task.subject)}`} data-testid={`subject-${task.subject}`}>
            {task.subject.charAt(0).toUpperCase() + task.subject.slice(1)}
          </Badge>
        </div>
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(task);
            }}
            className="h-8 w-8 p-0"
            data-testid={`button-edit-${task.id}`}
          >
            <Edit className="w-4 h-4 text-muted-foreground" />
          </Button>
        </div>
      </div>
      
      <h3 
        className={`font-semibold text-foreground mb-2 ${
          task.status === "completed" ? "line-through" : ""
        }`}
        data-testid={`task-title-${task.id}`}
      >
        {task.title}
      </h3>
      
      {task.description && (
        <p className="text-sm text-muted-foreground mb-4" data-testid={`task-description-${task.id}`}>
          {task.description}
        </p>
      )}
      
      <div className="space-y-3">
        {/* Progress Bar */}
        
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            Progress</span>
            <span data-testid={`task-progress-${task.id}`}>{task.progress}%</span>
          </div>
          <Progress 
            value={task.progress} 
            className={`h-2 ${task.status === "completed" ? "[&>div]:bg-green-500" : ""}`}
          />
        </div>
        
        {/* Due Date */}
        <div className="flex items-center justify-between text-sm">
          <div className={`flex items-center space-x-2 ${getDueDateColor()}`}>
            <DueDateIcon className="w-4 h-4" />
            <span data-testid={`task-due-date-${task.id}`}>{getDueDateText()}</span>
          </div>
          <Badge className={`text-xs ${getStatusColor(task.status)}`} data-testid={`task-status-${task.id}`}>
            {getStatusLabel(task.status)}
          </Badge>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="mt-4 pt-3 border-t border-border flex space-x-2">
        {task.status === "completed" ? (
          <Button 
            variant="secondary" 
            className="flex-1" 
            size="sm"
            onClick={handleUndoComplete}
            disabled={updateTaskMutation.isPending}
            data-testid={`button-undo-complete-${task.id}`}
          >
            <Undo className="w-4 h-4 mr-1" />
            Reopen Task
          </Button>
        ) === "todo" ? (
          <Button 
            className="flex-1" 
            size="sm"
            onClick={handleStartTask}
            disabled={updateTaskMutation.isPending}
            data-testid={`button-start-${task.id}`}
          >
            <Play className="w-4 h-4 mr-1" />
            Start Task
          </Button>
        ) : (
          <Button 
            className="flex-1" 
            size="sm"
            onClick={handleMarkComplete}
            disabled={updateTaskMutation.isPending}
            data-testid={`button-complete-${task.id}`}
          >
            {updateTaskMutation.isPending ? (
              <div className="spinner mr-1" />
            ) : (
              <CheckCircle className="w-4 h-4 mr-1" />
            )}
            Mark Complete
          </Button>
        )}
        
        {isOverdue && task.status !== "completed" && (
          <Button
            variant="secondary"
            size="sm"
            onClick={handleExtendDeadline}
            className="px-3"
            data-testid={`button-extend-${task.id}`}
          >
            <CalendarPlus className="w-4 h-4 text-orange-500" />
          </Button>
        )}
        
        <Button
          variant="secondary"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(task);
          }}
          className="px-3"
          data-testid={`button-delete-${task.id}`}
        >
          <Trash2 className="w-4 h-4 text-destructive" />
        </Button>
      </div>
    </div>
  );
}