import { Search, Plus, Undo, Redo, Grid3X3, List, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";


export default function Header({
  searchValue,
  onSearchChange,
  searchResultsText,
  onAddTask,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  tasksCount,
  totalTasks,
  activeFilters,
  onClearFilters,
}) {
  
  const getFilterLabel = (key, value) => {
    switch (key) {
      case "subject":
        return value.charAt(0).toUpperCase() + value.slice(1);
      case "priority":
        return `${value.charAt(0).toUpperCase() + value.slice(1)} Priority`;
      case "status"=== "todo" ? "To Do" === "in_progress" ? "In Progress" 
               value.charAt(0).toUpperCase() + value.slice(1);
      default;
    }
  };

  const getFilterVariant = (key, value) => {
    if (key === "priority" && value === "high") return "destructive";
    if (key === "status" && value === "completed") return "secondary";
    return "default";
  };

  return (
    <header className="bg-card border-b border-border px-6 py-4" data-testid="header">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-semibold" data-testid="page-title">All Tasks</h2>
          
          {/* Breadcrumb */}
          <nav className="flex items-center space-x-2 text-sm text-muted-foreground" data-testid="breadcrumb">
            Dashboard</span>
            <span className="text-xs">›</span>
            <span className="text-foreground">Tasks</span>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          {/* Undo/Redo Controls */}
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1" data-testid="undo-redo-controls">
            <Button
              variant="ghost"
              size="sm"
              onClick={onUndo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
              data-testid="button-undo"
            >
              <Undo className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onRedo}
              disabled={!canRedo}
              title="Redo (Ctrl+Y)"
              data-testid="button-redo"
            >
              <Redo className="w-4 h-4" />
            </Button>
          </div>

          {/* Search Bar */}
          <div className="relative" data-testid="search-container">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="Search tasks..."
              value={searchValue}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10 pr-20 w-80"
              data-testid="input-search"
            />
            {searchResultsText && (
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-muted-foreground">
                {searchResultsText}
              </div>
            )}
          </div>

          {/* View Toggle */}
          <div className="flex items-center bg-muted rounded-lg p-1" data-testid="view-toggle">
            <Button variant="default" size="sm" className="px-3">
              <Grid3X3 className="w-4 h-4 mr-1" />
              Grid
            </Button>
            <Button variant="ghost" size="sm" className="px-3">
              <List className="w-4 h-4 mr-1" />
              List
            </Button>
          </div>

          {/* Add Task Button */}
          <Button onClick={onAddTask} className="flex items-center space-x-2" data-testid="button-add-task">
            <Plus className="w-4 h-4" />
            Add Task</span>
          </Button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="mt-4 flex items-center justify-between text-sm">
        <div className="flex items-center space-x-4">
          <span className="text-muted-foreground" data-testid="tasks-count">
            Showing <span className="font-medium text-foreground">{tasksCount}</span> of {totalTasks} tasks
          </span>
          
          {/* Active Filters */}
          {activeFilters.length > 0 && (
            <div className="flex items-center space-x-2" data-testid="active-filters">
              {activeFilters.map(([key, value]) => (
                <Badge 
                  key={`${key}-${value}`} 
                  variant={getFilterVariant(key, value)}
                  className="text-xs"
                  data-testid={`filter-${key}-${value}`}
                >
                  {getFilterLabel(key, value)}
                </Badge>
              ))}
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearFilters}
                className="h-6 w-6 p-0"
                title="Clear filters"
                data-testid="button-clear-filters"
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          )}
        </div>

        {/* Sort Controls */}
        <div className="flex items-center space-x-2" data-testid="sort-controls">
          <span className="text-muted-foreground">Sort by:</span>
          <Select defaultValue="dueDate">
            <SelectTrigger className="w-32 h-8 text-xs" data-testid="select-sort">
              <SelectValue />
            </SelectTrigger>
            
              <SelectItem value="dueDate">Due Date</SelectItem>
              <SelectItem value="priority">Priority</SelectItem>
              <SelectItem value="createdAt">Created Date</SelectItem>
              <SelectItem value="subject">Subject</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </header>
  );
}