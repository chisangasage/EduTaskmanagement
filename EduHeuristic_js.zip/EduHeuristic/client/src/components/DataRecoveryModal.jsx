import { useState } from "react";
import { X, TriangleAlert } from "lucide-react";
import { useBackup } from "@/hooks/use-backup";
import { formatBackupDate, getTaskSummary } from "@/lib/backup";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";


export default function DataRecoveryModal({ isOpen, onClose, onSuccess }) {
  const [selectedBackupId, setSelectedBackupId] = useState("");
  const [recoveryOption, setRecoveryOption] = useState("replace");
  
  const { backups = [], restoreBackupMutation } = useBackup();

  const handleRestore = async () => {
    if (!selectedBackupId) return;
    
    try {
      await restoreBackupMutation.mutateAsync({
        backupId
        replaceAll=== "replace",
      });
      onSuccess();
    } catch (error) {
      console.error("Failed to restore backup:", error);
    }
  };

  const handleClose = () => {
    setSelectedBackupId("");
    setRecoveryOption("replace");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-auto" data-testid="recovery-modal">
        
          <DialogTitle className="flex items-center justify-between" data-testid="modal-title">
            Data Recovery
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={handleClose}
              data-testid="button-close-modal"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Select a backup to restore your tasks from. This will replace your current tasks.
          </p>

          {/* Backup List */}
          <div className="space-y-3 max-h-60 overflow-auto" data-testid="backup-list">
            {backups.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground" data-testid="no-backups">
                No backups available</p>
                <p className="text-xs mt-1">Create a backup first to enable recovery</p>
              </div>
            ) : (
              <RadioGroup value={selectedBackupId} onValueChange={setSelectedBackupId}>
                {backups.map((backup) => {
                  const summary = getTaskSummary(backup.data);
                  return (
                    <div
                      key={backup.id}
                      className="border border-border rounded-lg p-3 cursor-pointer hover:bg-muted transition-colors"
                      data-testid={`backup-${backup.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium text-sm" data-testid={`backup-date-${backup.id}`}>
                            {formatBackupDate(backup.createdAt)}
                          </div>
                          <div className="text-xs text-muted-foreground" data-testid={`backup-details-${backup.id}`}>
                            {summary.total} tasks, {summary.completed} completed
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span 
                            className={`text-xs px-2 py-1 rounded ${
                              backup.type === "auto" 
                                ? "bg-green-100 text-green-700" 
                                : "bg-blue-100 text-blue-700"
                            }`}
                            data-testid={`backup-type-${backup.id}`}
                          >
                            {backup.type === "auto" ? "Auto" : "Manual"}
                          </span>
                          <RadioGroupItem 
                            value={backup.id} 
                            id={backup.id}
                            data-testid={`radio-backup-${backup.id}`}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </RadioGroup>
            )}
          </div>

          {/* Recovery Options */}
          {backups.length > 0 && (
            <>
              <div className="border-t border-border pt-4">
                <h4 className="font-medium text-sm mb-3" data-testid="recovery-options-title">Recovery Options</h4>
                <RadioGroup value={recoveryOption} onValueChange={setRecoveryOption}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="replace" id="replace" data-testid="radio-replace" />
                    <Label htmlFor="replace" className="text-sm">Replace all current tasks</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="merge" id="merge" data-testid="radio-merge" />
                    <Label htmlFor="merge" className="text-sm">Merge with current tasks</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Warning Message */}
              <Alert data-testid="warning-alert">
                <TriangleAlert className="h-4 w-4" />
                
                  This action cannot be undone. Consider creating a backup first.
                </AlertDescription>
              </Alert>
            </>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={handleClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              className="flex-1"
              onClick={handleRestore}
              disabled={!selectedBackupId || restoreBackupMutation.isPending || backups.length === 0}
              data-testid="button-restore"
            >
              {restoreBackupMutation.isPending ? (
                <>
                  <div className="spinner mr-2" />
                  Restoring...
                </>
              ) : (
                "Restore Tasks"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}