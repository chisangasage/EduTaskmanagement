import { TriangleAlert } from "lucide-react";
import { useDeleteTask } from "@/hooks/use-tasks";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Task } from "@shared/schema";


export default function ConfirmationModal({ isOpen, onClose, task, onConfirm }) {
  const deleteTaskMutation = useDeleteTask();

  const handleConfirmDelete = async () => {
    if (!task) return;
    
    try {
      await deleteTaskMutation.mutateAsync(task.id);
      onConfirm();
    } catch (error) {
      console.error("Failed to delete task:", error);
    }
  };

  if (!task) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-sm" data-testid="confirmation-modal">
        
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-destructive/10 rounded-full flex items-center justify-center mr-3">
              <TriangleAlert className="w-5 h-5 text-destructive" />
            </div>
            
              <DialogTitle className="text-left" data-testid="modal-title">Delete Task</DialogTitle>
              <p className="text-sm text-muted-foreground">This action cannot be undone</p>
            </div>
          </div>
        </DialogHeader>

        <p className="text-sm text-muted-foreground mb-6" data-testid="confirmation-message">
          Are you sure you want to delete{" "}
          <span className="font-medium text-foreground" data-testid="task-title">
            "{task.title}"
          </span>
          ?
        </p>

        <div className="flex space-x-3">
          <Button
            variant="secondary"
            className="flex-1"
            onClick={onClose}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            className="flex-1"
            onClick={handleConfirmDelete}
            disabled={deleteTaskMutation.isPending}
            data-testid="button-confirm-delete"
          >
            {deleteTaskMutation.isPending ? (
              <>
                <div className="spinner mr-2" />
                Deleting...
              </>
            ) : (
              "Delete"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}