import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X } from "lucide-react";
import { useCreateTask, useUpdateTask } from "@/hooks/use-tasks";
import { insertTaskSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Task } from "@shared/schema";

const taskFormSchema = insertTaskSchema.extend({
  dueDate: z.string().min(1, "Due date is required"),
});



export default function TaskModal({ isOpen, onClose, task, onSuccess }) {
  const createTaskMutation = useCreateTask();
  const updateTaskMutation = useUpdateTask();
  const isEditing = !!task;

  const form = useForm({
    resolver: zodResolver(taskFormSchema),
    defaultValues
      title: "",
      description: "",
      subject: "",
      priority: "",
      status: "todo",
      progress
      dueDate: "",
    },
  });

  useEffect(() => {
    if (isOpen) {
      if (task) {
        // Editing existing task
        const dueDate = new Date(task.dueDate);
        const formattedDate = new Date(dueDate.getTime() - dueDate.getTimezoneOffset() * 60000)
          .toISOString()
          .slice(0, 16);
        
        form.reset({
          title
          description: task.description || "",
          subject
          priority
          status
          progress
          dueDate);
      } else {
        // Creating new task
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(23, 59);
        const formattedDate = new Date(tomorrow.getTime() - tomorrow.getTimezoneOffset() * 60000)
          .toISOString()
          .slice(0, 16);

        form.reset({
          title: "",
          description: "",
          subject: "",
          priority: "",
          status: "todo",
          progress
          dueDate);
      }
    }
  }, [isOpen, task, form]);

  const onSubmit = async (data) => {
    try {
      const dueDate = new Date(data.dueDate);
      
      if (isEditing && task) {
        await updateTaskMutation.mutateAsync({
          id
          dueDate: dueDate.toISOString(),
        });
      } else {
        await createTaskMutation.mutateAsync({
          ...data,
          dueDate: dueDate.toISOString(),
        });
      }
      
      onSuccess();
    } catch (error) {
      console.error("Failed to save task:", error);
    }
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  const isSubmitting = createTaskMutation.isPending || updateTaskMutation.isPending;
  const progressValue = form.watch("progress");

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" data-testid="task-modal">
        
          <DialogTitle data-testid="modal-title">
            {isEditing ? "Edit Task" : "Add New Task"}
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-4 top-4 h-6 w-6 p-0"
            onClick={handleClose}
            data-testid="button-close-modal"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" data-testid="task-form">
            {/* Task Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                
                  <FormLabel data-testid="label-title">Task Title *</FormLabel>
                  
                    <Input
                      placeholder="Enter task title..."
                      {...field}
                      data-testid="input-title"
                    />
                  </FormControl>
                  <FormMessage data-testid="error-title" />
                </FormItem>
              )}
            />

            {/* Task Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                
                  <FormLabel data-testid="label-description">Description</FormLabel>
                  
                    <Textarea
                      placeholder="Describe your task..."
                      rows={3}
                      {...field}
                      value={field.value || ''}
                      data-testid="textarea-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Subject and Priority Row */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  
                    <FormLabel data-testid="label-subject">Subject *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      
                        <SelectTrigger data-testid="select-subject">
                          <SelectValue placeholder="Select subject" />
                        </SelectTrigger>
                      </FormControl>
                      
                        <SelectItem value="mathematics">Mathematics</SelectItem>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="history">History</SelectItem>
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage data-testid="error-subject" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  
                    <FormLabel data-testid="label-priority">Priority *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      
                        <SelectTrigger data-testid="select-priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage data-testid="error-priority" />
                  </FormItem>
                )}
              />
            </div>

            {/* Due Date */}
            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                
                  <FormLabel data-testid="label-due-date">Due Date *</FormLabel>
                  
                    <Input
                      type="datetime-local"
                      {...field}
                      data-testid="input-due-date"
                    />
                  </FormControl>
                  <div className="text-xs text-muted-foreground">
                    Select when this task should be completed
                  </div>
                  <FormMessage data-testid="error-due-date" />
                </FormItem>
              )}
            />

            {/* Progress Slider (Edit mode only) */}
            {isEditing && (
              <FormField
                control={form.control}
                name="progress"
                render={({ field }) => (
                  
                    <FormLabel data-testid="label-progress">Progress</FormLabel>
                    
                      <div className="space-y-2">
                        <Slider
                          value={[field.value || 0]}
                          onValueChange={(value) => field.onChange(value[0])}
                          max={100}
                          step={5}
                          className="w-full"
                          data-testid="slider-progress"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          0%</span>
                          <span data-testid="progress-value">{progressValue}%</span>
                          100%</span>
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Form Actions */}
            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={handleClose}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={isSubmitting}
                data-testid="button-submit"
              >
                {isSubmitting ? (
                  <>
                    <div className="spinner mr-2" />
                    {isEditing ? "Updating..." : "Creating..."}
                  </>
                ) : (
                  isEditing ? "Update Task" : "Create Task"
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}