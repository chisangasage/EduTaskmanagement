import { GraduationCap, ListCheck, Clock, Star, CheckCircle, Download, History } from "lucide-react";
import { useTaskCounts } from "@/hooks/use-tasks";
import { useBackup } from "@/hooks/use-backup";
import { formatBackupDate } from "@/lib/backup";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";


export default function Sidebar({ filters, onFiltersChange, onManualBackup, onDataRecovery }) {
  const { data= useTaskCounts();
  const { backups, createBackupMutation } = useBackup();
  
  const lastBackup = backups?.[0];
  const isBackupLoading = createBackupMutation.isPending;

  const navigationItems = [
    {
      icon
      label: "All Tasks",
      count
      isActive: !filters.status,
      onClick: () => onFiltersChange({ ...filters, status: "" }),
      testId: "nav-all-tasks",
    },
    {
      icon
      label: "Due Today",
      count
      isActive
      onClick: () => {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(0, 0, 0, 0);
        onFiltersChange({ 
          ...filters, 
          status: "todo",
          dueDateTo: tomorrow.toISOString() 
        });
      },
      variant: "destructive": "nav-due-today",
    },
    {
      icon
      label: "High Priority",
      count
      isActive=== "high",
      onClick: () => onFiltersChange({ ...filters, priority=== "high" ? "" : "high" }),
      variant: "warning": "nav-high-priority",
    },
    {
      icon
      label: "Completed",
      count
      isActive=== "completed",
      onClick: () => onFiltersChange({ ...filters, status=== "completed" ? "" : "completed" }),
      variant: "success": "nav-completed",
    },
  ];

  const getCountBadgeClass = (variant?) => {
    switch (variant) {
      case "destructive":
        return "bg-destructive text-destructive-foreground";
      case "warning":
        return "bg-yellow-500 text-white";
      case "success":
        return "bg-green-500 text-white";
      default:
        return "bg-primary text-primary-foreground";
    }
  };

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Logo and Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <GraduationCap className="text-primary-foreground text-sm" />
          </div>
          <h1 className="text-xl font-semibold" data-testid="app-title">StudyTracker</h1>
        </div>
        
        <div className="mt-4 flex items-center space-x-2 text-sm text-muted-foreground">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span data-testid="system-status">System Status: Online</span>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2" data-testid="navigation">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
          Navigation
        </div>
        
        {navigationItems.map((item) => (
          <button
            key={item.label}
            onClick={item.onClick}
            className={`flex items-center space-x-3 px-3 py-2 w-full text-left rounded-md transition-colors ${
              item.isActive
                ? "bg-accent text-accent-foreground"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
            }`}
            data-testid={item.testId}
          >
            <item.icon className="w-4 h-4" />
            {item.label}</span>
            <span className={`ml-auto text-xs px-2 py-1 rounded-full ${getCountBadgeClass(item.variant)}`}>
              {item.count}
            </span>
          </button>
        ))}

        {/* Filters Section */}
        <div className="pt-6">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Filters
          </div>
          
          <div className="space-y-3">
            
              <label className="text-sm font-medium text-foreground" data-testid="label-subject">Subject</label>
              <Select
                value={filters.subject || "all"}
                onValueChange={(value) => onFiltersChange({ ...filters, subject=== "all" ? "" )}
              >
                <SelectTrigger className="w-full mt-1" data-testid="select-subject">
                  <SelectValue placeholder="All Subjects" />
                </SelectTrigger>
                
                  <SelectItem value="all">All Subjects</SelectItem>
                  <SelectItem value="mathematics">Mathematics</SelectItem>
                  <SelectItem value="science">Science</SelectItem>
                  <SelectItem value="history">History</SelectItem>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            
              <label className="text-sm font-medium text-foreground" data-testid="label-status">Status</label>
              <Select
                value={filters.status || "all"}
                onValueChange={(value) => onFiltersChange({ ...filters, status=== "all" ? "" )}
              >
                <SelectTrigger className="w-full mt-1" data-testid="select-status">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </nav>

      {/* Backup Status Section */}
      <div className="p-4 border-t border-border" data-testid="backup-section">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
          Data Management
        </div>
        
        <div className="bg-muted rounded-lg p-3 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Auto Backup</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-muted-foreground" data-testid="backup-status">Active</span>
            </div>
          </div>
          
          <div className="text-xs text-muted-foreground">
            Last backup: <span data-testid="last-backup-time">
              {lastBackup ? formatBackupDate(lastBackup.createdAt) : "Never"}
            </span>
          </div>
          
          <div className="flex space-x-2">
            <Button
              size="sm"
              className="flex-1 text-xs"
              onClick={onManualBackup}
              disabled={isBackupLoading}
              data-testid="button-backup-now"
            >
              {isBackupLoading ? (
                <>
                  <div className="spinner mr-1"></div>
                  Backing up...
                </>
              ) : (
                <>
                  <Download className="w-3 h-3 mr-1" />
                  Backup Now
                </>
              )}
            </Button>
            
            <Button
              variant="secondary"
              size="sm"
              className="flex-1 text-xs"
              onClick={onDataRecovery}
              data-testid="button-restore"
            >
              <History className="w-3 h-3 mr-1" />
              Restore
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
}