import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import TaskCard from "@/components/TaskCard";
import TaskModal from "@/components/TaskModal";
import ConfirmationModal from "@/components/ConfirmationModal";
import DataRecoveryModal from "@/components/DataRecoveryModal";
import { useTasks } from "@/hooks/use-tasks";
import { useBackup } from "@/hooks/use-backup";
import { Search } from "lucide-react";

export default function TasksPage() {
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isRecoveryModalOpen, setIsRecoveryModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [filters, setFilters] = useState({
    status: "",
    subject: "",
    priority: "",
    search: "",
  });
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);

  const { data= [], isLoading, refetch } = useTasks(filters);
  const { createBackupMutation } = useBackup();

  const handleAddTask = () => {
    setEditingTask(null);
    setIsTaskModalOpen(true);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const handleDeleteTask = (task) => {
    setTaskToDelete(task);
    setIsConfirmModalOpen(true);
  };

  const handleUndo = () => {
    if (undoStack.length > 0) {
      const lastAction = undoStack[undoStack.length - 1];
      setRedoStack([...redoStack, lastAction]);
      setUndoStack(undoStack.slice(0, -1));
      // Implement undo logic based on action type
      refetch();
    }
  };

  const handleRedo = () => {
    if (redoStack.length > 0) {
      const lastRedo = redoStack[redoStack.length - 1];
      setUndoStack([...undoStack, lastRedo]);
      setRedoStack(redoStack.slice(0, -1));
      // Implement redo logic based on action type
      refetch();
    }
  };

  const handleManualBackup = () => {
    createBackupMutation.mutate();
  };

  const priorityOrder = { high, medium, low;
  const statusOrder = { overdue, todo, in_progress, completed;

  const sortedTasks = [...tasks].sort((a, b) => {
    // First sort by status (overdue first)
    const statusDiff = (statusOrder)[b.status] - (statusOrder)[a.status];
    if (statusDiff !== 0) return statusDiff;
    
    // Then by priority
    const priorityDiff = (priorityOrder)[b.priority] - (priorityOrder)[a.priority];
    if (priorityDiff !== 0) return priorityDiff;
    
    // Finally by due date
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  const filteredTasksCount = tasks.length;
  const searchResultsText = filters.search 
    ? filteredTasksCount === 0 
      ? "No results" 
      : `${filteredTasksCount} results`
    : "";

  return (
    <div className="min-h-screen flex bg-background text-foreground font-sans" data-testid="tasks-page">
      <Sidebar
        filters={filters}
        onFiltersChange={setFilters}
        onManualBackup={handleManualBackup}
        onDataRecovery={() => setIsRecoveryModalOpen(true)}
      />
      
      <main className="flex-1 flex flex-col">
        <Header
          searchValue={filters.search}
          onSearchChange={(search) => setFilters(prev => ({ ...prev, search }))}
          searchResultsText={searchResultsText}
          onAddTask={handleAddTask}
          onUndo={handleUndo}
          onRedo={handleRedo}
          canUndo={undoStack.length > 0}
          canRedo={redoStack.length > 0}
          tasksCount={filteredTasksCount}
          totalTasks={tasks.length}
          activeFilters={Object.entries(filters).filter(([key, value]) => value && key !== 'search')}
          onClearFilters={() => setFilters({ status: "", subject: "", priority: "", search)}
        />

        <div className="flex-1 p-6 overflow-auto" data-testid="tasks-content">
          {isLoading ? (
            <div className="flex items-center justify-center h-64" data-testid="loading-state">
              <div className="spinner"></div>
              <span className="ml-2 text-muted-foreground">Loading tasks...</span>
            </div>
          ) === 0 ? (
            <div className="text-center py-12" data-testid="no-results-state">
              <div className="text-muted-foreground mb-4">
                <Search className="w-12 h-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">
                {filters.search || filters.status || filters.subject || filters.priority 
                  ? "No tasks found" 
                  : "No tasks yet"}
              </h3>
              <p className="text-muted-foreground mb-4">
                {filters.search || filters.status || filters.subject || filters.priority
                  ? "Try adjusting your search terms or filters."
                  : "Create your first task to get started."}
              </p>
              {(filters.search || filters.status || filters.subject || filters.priority) ? (
                <button 
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
                  onClick={() => setFilters({ status: "", subject: "", priority: "", search: "" })}
                  data-testid="button-clear-filters"
                >
                  Clear All Filters
                </button>
              ) : (
                <button 
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
                  onClick={handleAddTask}
                  data-testid="button-add-first-task"
                >
                  Add Your First Task
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" data-testid="tasks-grid">
              {sortedTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onEdit={handleEditTask}
                  onDelete={handleDeleteTask}
                  onRefetch={refetch}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        task={editingTask}
        onSuccess={() => {
          refetch();
          setIsTaskModalOpen(false);
        }}
      />

      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        task={taskToDelete}
        onConfirm={() => {
          setIsConfirmModalOpen(false);
          refetch();
        }}
      />

      <DataRecoveryModal
        isOpen={isRecoveryModalOpen}
        onClose={() => setIsRecoveryModalOpen(false)}
        onSuccess={() => {
          refetch();
          setIsRecoveryModalOpen(false);
        }}
      />
    </div>
  );
}