import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Backup } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useBackups() {
  return useQuery({
    queryKey: ['/api/backups'],
    queryFn: async () => {
      const response = await fetch('/api/backups');
      if (!response.ok) throw new Error('Failed to fetch backups');
      return response.json();
    },
  });
}

export function useCreateBackup() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/backups');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/backups'] });
      toast({
        title: "Backup Created",
        description: "Your tasks have been backed up successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Backup Failed",
        description: "Failed to create backup. Please try again.",
        variant: "destructive",
      });
    },
  });
}

export function useRestoreBackup() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ backupId, replaceAll = true }: { backupId; replaceAll?) => {
      const response = await apiRequest('POST', `/api/backups/${backupId}/restore`, { replaceAll });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/counts'] });
      toast({
        title: "Restore Complete",
        description: "Your tasks have been restored successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Restore Failed",
        description: "Failed to restore backup. Please try again.",
        variant: "destructive",
      });
    },
  });
}

export function useBackup() {
  const createBackupMutation = useCreateBackup();
  const restoreBackupMutation = useRestoreBackup();
  const { data= useBackups();
  
  return {
    backups,
    isLoading,
    createBackupMutation,
    restoreBackupMutation,
  };
}